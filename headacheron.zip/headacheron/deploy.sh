#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
VERSION="$(cat "$SCRIPT_DIR/VERSION" 2>/dev/null || printf 'unknown')"
printf '[headacheron installer %s]\n' "$VERSION"

INSTALL_DIR="${HEADACHERON_INSTALL_DIR:-$HOME/.local/opt/headacheron}"
BIND_ADDRESS="${HEADACHERON_BIND_ADDRESS:-0.0.0.0}"
WEB_PORT="${HEADACHERON_PORT:-8080}"
PATCH_FILE="$SCRIPT_DIR/headacheron.patch"
SOURCE_ARCHIVE="$SCRIPT_DIR/acheron-source.zip"
SOURCE_SHA256="20c081eec7d4be4c89ab2682bd4d5213f41e17490082ad274c9731fcf2906ff1"
MANAGED_MARKER=".headacheron-managed"
ENV_DIR="$HOME/.config/headacheron"
ENV_FILE="$ENV_DIR/headacheron.env"
UNIT_DIR="$HOME/.config/systemd/user"
UNIT_FILE="$UNIT_DIR/headacheron.service"
CURL_IMPERSONATE_VERSION="v2.0.0"
CURL_IMPERSONATE_SHA256="d8a98bc123fae4f04bb6a7584ff486333a334b3b08edaba1867929ae8d6ebb4d"
CURL_IMPERSONATE_DIR="${HEADACHERON_CURL_IMPERSONATE_DIR:-$INSTALL_DIR/.deps/curl-impersonate-$CURL_IMPERSONATE_VERSION}"
CURL_IMPERSONATE_ARCHIVE="$INSTALL_DIR/.deps/libcurl-impersonate-$CURL_IMPERSONATE_VERSION.x86_64-linux-gnu.tar.gz"
CURL_IMPERSONATE_URL="https://github.com/lexiforest/curl-impersonate/releases/download/$CURL_IMPERSONATE_VERSION/libcurl-impersonate-$CURL_IMPERSONATE_VERSION.x86_64-linux-gnu.tar.gz"

die() {
    printf 'Error: %s\n' "$*" >&2
    exit 1
}

case "$INSTALL_DIR" in
    /*) ;;
    *) die "HEADACHERON_INSTALL_DIR must be an absolute path" ;;
esac
case "$INSTALL_DIR" in
    *[$'\t\r\n ']* ) die "The installation path cannot contain whitespace" ;;
esac
case "$CURL_IMPERSONATE_DIR" in
    /*) ;;
    *) die "HEADACHERON_CURL_IMPERSONATE_DIR must be an absolute path" ;;
esac

[[ "$WEB_PORT" =~ ^[0-9]+$ ]] || die "HEADACHERON_PORT must be numeric"
(( WEB_PORT >= 1 && WEB_PORT <= 65535 )) || die "HEADACHERON_PORT must be between 1 and 65535"
[[ "$BIND_ADDRESS" =~ ^[0-9A-Fa-f:.]+$ ]] || \
    die "HEADACHERON_BIND_ADDRESS must be a numeric IPv4 or IPv6 address"
[[ -f "$PATCH_FILE" ]] || die "Missing $PATCH_FILE"
[[ -f "$SOURCE_ARCHIVE" ]] || die "Missing embedded Acheron source archive: $SOURCE_ARCHIVE"
printf '%s  %s\n' "$SOURCE_SHA256" "$SOURCE_ARCHIVE" | sha256sum --check --status || \
    die "Embedded Acheron source archive failed checksum verification"
[[ "$(uname -m)" == "x86_64" ]] || \
    die "This bundle currently supports x86-64 Linux only (detected $(uname -m))"

if [[ -e "$HOME/acheron-headless" || -e "$HOME/.config/systemd/user/acherond.service" ]]; then
    printf 'Note: a legacy acherond install still exists. This installer will not modify it.\n'
    printf '      Run %s/uninstall.sh --legacy if you want it removed.\n' "$SCRIPT_DIR"
fi

if [[ "${HEADACHERON_SKIP_PACKAGES:-0}" != "1" ]]; then
    command -v apt-get >/dev/null 2>&1 || \
        die "Automatic package installation supports Debian/Ubuntu only; set HEADACHERON_SKIP_PACKAGES=1 for manual dependency management"
    command -v sudo >/dev/null 2>&1 || die "sudo is required to install packages"

    sudo apt-get update
    sudo apt-get install -y \
        build-essential binutils ca-certificates cmake curl ninja-build pkg-config openssl patch unzip \
        qt6-base-dev qt6-svg-dev qt6-tools-dev qt6-tools-dev-tools qt6-l10n-tools \
        libqt6sql6-sqlite libxkbcommon-dev nlohmann-json3-dev \
        libcurl4-openssl-dev libssl-dev libsodium-dev \
        libopus-dev libavcodec-dev libavformat-dev libavutil-dev libswscale-dev \
        libswresample-dev libsecret-1-dev libgcrypt20-dev dbus-user-session \
        gnome-keyring
fi

for command_name in cmake ninja pkg-config openssl curl tar unzip patch sha256sum nm objcopy; do
    command -v "$command_name" >/dev/null 2>&1 || die "Required command not found: $command_name"
done

refresh_embedded_source() {
    local scratch source_root preserve_root=""
    scratch="$(mktemp -d)"
    trap 'rm -rf -- "$scratch" "${preserve_root:-}"' RETURN

    unzip -q "$SOURCE_ARCHIVE" -d "$scratch"
    source_root="$(find "$scratch" -mindepth 1 -maxdepth 1 -type d -print -quit)"
    [[ -n "$source_root" && -f "$source_root/CMakeLists.txt" ]] || \
        die "Embedded source archive has an unexpected layout"

    if [[ -e "$INSTALL_DIR" ]]; then
        if [[ ! -f "$INSTALL_DIR/$MANAGED_MARKER" && ! -d "$INSTALL_DIR/.git" && \
              ! -f "$INSTALL_DIR/src/Headless/HeadlessController.cpp" ]]; then
            die "$INSTALL_DIR exists and does not look like a managed headacheron install"
        fi

        preserve_root="$(mktemp -d)"
        for keep in .deps build vendor; do
            if [[ -e "$INSTALL_DIR/$keep" ]]; then
                mv "$INSTALL_DIR/$keep" "$preserve_root/$keep"
            fi
        done
        rm -rf -- "$INSTALL_DIR"
    fi

    mkdir -p "$INSTALL_DIR"
    cp -a "$source_root/." "$INSTALL_DIR/"

    # The GitHub source archive intentionally contains empty submodule folders.
    # Reuse previously downloaded vendor sources when updating.
    rm -rf "$INSTALL_DIR/vendor"
    if [[ -n "$preserve_root" && -d "$preserve_root/vendor" ]]; then
        mv "$preserve_root/vendor" "$INSTALL_DIR/vendor"
    else
        mkdir -p "$INSTALL_DIR/vendor"
    fi
    for keep in .deps build; do
        if [[ -n "$preserve_root" && -e "$preserve_root/$keep" ]]; then
            mv "$preserve_root/$keep" "$INSTALL_DIR/$keep"
        fi
    done

    if ! patch --batch --forward --dry-run -d "$INSTALL_DIR" -p1 < "$PATCH_FILE" >/dev/null; then
        die "The bundled headacheron patch does not match the embedded Acheron source"
    fi
    patch --batch --forward -d "$INSTALL_DIR" -p1 < "$PATCH_FILE" >/dev/null
    printf '%s\n' "$VERSION" > "$INSTALL_DIR/$MANAGED_MARKER"

    trap - RETURN
    rm -rf -- "$scratch" "${preserve_root:-}"
}

fetch_vendor() {
    local name="$1" repo="$2" commit="$3" probe="$4"
    local target="$INSTALL_DIR/vendor/$name"
    [[ -f "$target/$probe" ]] && return 0

    printf 'Installing pinned vendor source: %s\n' "$name"
    rm -rf -- "$target"
    mkdir -p "$target"

    local archive
    archive="$(mktemp)"
    if ! curl --fail --location --retry 3 \
        --output "$archive" "https://codeload.github.com/$repo/tar.gz/$commit"; then
        rm -f "$archive"
        die "Could not download vendor source $name"
    fi
    if ! tar -xzf "$archive" --strip-components=1 -C "$target"; then
        rm -f "$archive"
        die "Could not extract vendor source $name"
    fi
    rm -f "$archive"
    [[ -f "$target/$probe" ]] || die "Vendor source $name is incomplete after extraction"
}

printf 'Refreshing Acheron from the source embedded in this package\n'
refresh_embedded_source

# These are the exact submodule revisions used by the embedded Acheron snapshot.
# They are downloaded only when missing and are preserved across installer updates.
fetch_vendor "emoji-segmenter" "google/emoji-segmenter" \
    "1cada87c62550446fca6a42a69743688b4539a4c" "emoji_presentation_scanner.c"
fetch_vendor "libdave" "discord/libdave" \
    "52cd56dc550f447fb354b3a06c9e2d2e2a4309c6" "cpp/CMakeLists.txt"
fetch_vendor "miniaudio" "mackron/miniaudio" \
    "13d161bc8d856ad61ae46b798bbeffc0f49808e8" "miniaudio.h"
fetch_vendor "mlspp" "cisco/mlspp" \
    "92aaa4134fa45ec39957a7c81a342401fba7feb2" "CMakeLists.txt"
fetch_vendor "qrcodegen" "nayuki/QR-Code-generator" \
    "720f62bddb7226106071d4728c292cb1df519ceb" "cpp/qrcodegen.cpp"
fetch_vendor "qtkeychain" "frankosterfeld/qtkeychain" \
    "844beb4772d18b36f848c22df584d4fee4be40f1" "CMakeLists.txt"

grep -Fq 'qt_add_executable(headacheron' "$INSTALL_DIR/CMakeLists.txt" || \
    die "headacheron build target is missing after patch installation"
grep -Fq 'QT_VERSION_CHECK(6, 9, 0)' "$INSTALL_DIR/src/qt_flags.hpp" || \
    die "Qt 6.4 compatibility fix is missing"
grep -Fq 'qHash(Client::MessageLoadType' "$INSTALL_DIR/src/Discord/Client.hpp" || \
    die "Qt 6.4 enum hash compatibility fix is missing"
grep -Fq 'IcyMetadataMonitor' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "ICY metadata monitor is missing"
grep -Fq 'readyAccounts.contains' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Discord READY-state fix is missing"
grep -Fq 'metadata.buttonUrls' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Rich Presence button fix is missing"
grep -Fq 'headless/button_2_url' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Second Rich Presence button support is missing"
grep -Fq 'activity.applicationId' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Rich Presence application ID support is missing"
grep -Fq 'proxyExternalAsset' "$INSTALL_DIR/src/Discord/Client.cpp" || \
    die "Discord external artwork proxy support is missing"
grep -Fq 'assets.largeImage = proxiedAsset' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Rich Presence is not using Discord media-proxy artwork"
grep -Fq 'activity.flags = 1' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Rich Presence INSTANCE flag is missing"
grep -Fq 'headless/presence_enabled", false' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Rich Presence is not disabled by default"
if grep -Fq 'setExclusiveAutoConnect' "$INSTALL_DIR/src/Headless/HeadlessController.cpp"; then
    die "Old exclusive startup-account logic is still present"
fi
grep -Fq 'accountRepo.updateAutoConnect' "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Per-account startup selection is missing"
grep -Fq 'syncAccountCard' "$INSTALL_DIR/resources/headless/app.js" || \
    die "Live multi-account UI refresh fix is missing"
grep -Fq 'align-self: start; align-content: start' "$INSTALL_DIR/resources/headless/style.css" || \
    die "Account-card sizing fix is missing"
grep -Fq 'value["streamUrl"] = settingString(settings, "headless/stream_url");' \
    "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Stream URL is not blank by default"
grep -Fq 'value["listeningName"] = settingString(settings, "headless/listening_name");' \
    "$INSTALL_DIR/src/Headless/HeadlessController.cpp" || \
    die "Listening activity name is not blank by default"
if grep -Fq 'assets.largeUrl = settingString(settings, "headless/stream_url")' \
    "$INSTALL_DIR/src/Headless/HeadlessController.cpp"; then
    die "Old stream-artwork click-through code is still present"
fi
printf 'Verified embedded source, account fixes, and Rich Presence fixes\n'

if [[ ! -f "$CURL_IMPERSONATE_DIR/include/curl/curl.h" || \
      ! -f "$CURL_IMPERSONATE_DIR/libcurl-impersonate-local.a" ]]; then
    printf 'Installing curl-impersonate %s for Discord WebSocket support\n' "$CURL_IMPERSONATE_VERSION"
    mkdir -p "$INSTALL_DIR/.deps" "$CURL_IMPERSONATE_DIR"
    curl --fail --location --retry 3 --output "$CURL_IMPERSONATE_ARCHIVE" \
        "$CURL_IMPERSONATE_URL"
    printf '%s  %s\n' "$CURL_IMPERSONATE_SHA256" "$CURL_IMPERSONATE_ARCHIVE" | \
        sha256sum --check --status || die "curl-impersonate archive checksum verification failed"
    tar -xzf "$CURL_IMPERSONATE_ARCHIVE" -C "$CURL_IMPERSONATE_DIR"

    mapfile -t curl_symbols < <(
        nm --defined-only -g "$CURL_IMPERSONATE_DIR/libcurl-impersonate.a" |
            awk '{print $NF}' | grep '^curl_' | sort -u
    )
    (( ${#curl_symbols[@]} > 0 )) || die "No curl symbols found in curl-impersonate archive"
    objcopy_args=()
    for symbol in "${curl_symbols[@]}"; do
        objcopy_args+=("--keep-global-symbol=$symbol")
    done
    objcopy "${objcopy_args[@]}" \
        "$CURL_IMPERSONATE_DIR/libcurl-impersonate.a" \
        "$CURL_IMPERSONATE_DIR/libcurl-impersonate-local.a"
fi
[[ -f "$CURL_IMPERSONATE_DIR/include/curl/curl.h" ]] || die "curl-impersonate headers are missing"
[[ -f "$CURL_IMPERSONATE_DIR/libcurl-impersonate-local.a" ]] || die "curl-impersonate library is missing"

if [[ -f "$INSTALL_DIR/build/CMakeCache.txt" ]] && \
   ! grep -Fq "$CURL_IMPERSONATE_DIR" "$INSTALL_DIR/build/CMakeCache.txt"; then
    printf 'Discarding old CMake cache\n'
    rm -f -- "$INSTALL_DIR/build/CMakeCache.txt"
fi

printf 'Configuring headacheron\n'
cmake -S "$INSTALL_DIR" -B "$INSTALL_DIR/build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCURL_INCLUDE_DIR="$CURL_IMPERSONATE_DIR/include" \
    -DCURL_LIBRARY="$CURL_IMPERSONATE_DIR/libcurl-impersonate-local.a" \
    -DUSE_VCPKG=OFF \
    -DBUILD_TESTS=OFF \
    -DBUILD_HEADLESS_WEBUI=ON \
    -DENABLE_VOICE=ON \
    -DENABLE_FFMPEG=ON \
    -DENABLE_RNNOISE=OFF \
    -DALLOW_PLAIN_CURL=OFF

grep -Fq "$CURL_IMPERSONATE_DIR" "$INSTALL_DIR/build/CMakeCache.txt" || \
    die "CMake did not select curl-impersonate"

printf 'Building headacheron\n'
cmake --build "$INSTALL_DIR/build" --target headacheron --parallel "$(nproc)"
[[ -x "$INSTALL_DIR/build/headacheron" ]] || die "Build completed without producing build/headacheron"
if ldd "$INSTALL_DIR/build/headacheron" | grep -q 'libcurl\.so'; then
    die "headacheron still links the system libcurl and cannot open Discord WebSockets"
fi

if [[ "${HEADACHERON_SKIP_SERVICE:-0}" == "1" ]]; then
    printf '\nBuild complete: %s/build/headacheron\n' "$INSTALL_DIR"
    printf 'Example manual run:\n'
    printf '  HEADACHERON_WEB_TOKEN="$(openssl rand -hex 32)" %s/build/headacheron --listen %s --port %s\n' \
        "$INSTALL_DIR" "$BIND_ADDRESS" "$WEB_PORT"
    exit 0
fi

mkdir -p "$ENV_DIR" "$UNIT_DIR"
chmod 700 "$ENV_DIR"

generated_token=""
if [[ ! -f "$ENV_FILE" ]]; then
    generated_token="$(openssl rand -hex 32)"
    umask 077
    printf 'HEADACHERON_WEB_TOKEN=%s\n' "$generated_token" > "$ENV_FILE"
fi
if ! grep -q '^HEADACHERON_TOKENSTORE_INSECURE_FALLBACK=' "$ENV_FILE"; then
    printf 'HEADACHERON_TOKENSTORE_INSECURE_FALLBACK=1\n' >> "$ENV_FILE"
fi
chmod 600 "$ENV_FILE"

{
    printf '[Unit]\n'
    printf 'Description=headacheron Discord stream relay\n'
    printf 'After=network-online.target\n'
    printf 'Wants=network-online.target\n\n'
    printf '[Service]\n'
    printf 'Type=simple\n'
    printf 'WorkingDirectory=%s\n' "$INSTALL_DIR"
    printf 'EnvironmentFile=%s\n' "$ENV_FILE"
    printf 'ExecStart=%s/build/headacheron --listen %s --port %s\n' \
        "$INSTALL_DIR" "$BIND_ADDRESS" "$WEB_PORT"
    printf 'Restart=on-failure\n'
    printf 'RestartSec=5\n'
    printf 'UMask=0077\n'
    printf 'NoNewPrivileges=true\n'
    printf 'PrivateTmp=true\n\n'
    printf '[Install]\n'
    printf 'WantedBy=default.target\n'
} > "$UNIT_FILE"

if systemctl --user daemon-reload && \
   systemctl --user enable headacheron.service && \
   systemctl --user restart headacheron.service; then
    printf '\nheadacheron is installed and running.\n'
else
    printf '\nBuild succeeded, but systemd --user was unavailable in this shell.\n' >&2
    printf 'Run later:\n' >&2
    printf '  systemctl --user daemon-reload\n' >&2
    printf '  systemctl --user enable --now headacheron.service\n' >&2
fi

printf 'Web UI bind: http://%s:%s\n' "$BIND_ADDRESS" "$WEB_PORT"
if [[ -n "$generated_token" ]]; then
    printf 'Web access token: %s\n' "$generated_token"
else
    printf 'Existing web access token retained in %s\n' "$ENV_FILE"
fi
printf 'Service: systemctl --user status headacheron\n'
printf 'Logs:    journalctl --user -u headacheron -f\n'

#!/usr/bin/env bash
set -Eeuo pipefail

REMOVE_DATA=0
REMOVE_LEGACY=0

usage() {
    cat <<'TXT'
Usage: ./uninstall.sh [--purge] [--legacy]

  --purge   Also remove headacheron settings, saved tokens, and local app data.
  --legacy  Also remove old acherond / acheron-headless installs and their data.
TXT
}

for arg in "$@"; do
    case "$arg" in
        --purge) REMOVE_DATA=1 ;;
        --legacy) REMOVE_LEGACY=1 ;;
        -h|--help) usage; exit 0 ;;
        *) printf 'Unknown option: %s\n' "$arg" >&2; usage >&2; exit 2 ;;
    esac
done

systemctl --user disable --now headacheron.service 2>/dev/null || true
pkill -x headacheron 2>/dev/null || true
rm -f "$HOME/.config/systemd/user/headacheron.service"
systemctl --user daemon-reload 2>/dev/null || true
systemctl --user reset-failed 2>/dev/null || true

rm -rf "$HOME/.local/opt/headacheron"
rm -f "$HOME/.local/bin/headacheron"

if (( REMOVE_DATA == 1 )); then
    rm -rf "$HOME/.config/headacheron"
    rm -rf "$HOME/.local/share/headacheron"
    rm -rf "$HOME/.cache/headacheron"
fi

if (( REMOVE_LEGACY == 1 )); then
    systemctl --user disable --now acherond.service 2>/dev/null || true
    pkill -x acherond 2>/dev/null || true
    rm -f "$HOME/.config/systemd/user/acherond.service"
    rm -rf "$HOME/acheron-headless"
    rm -rf "$HOME/.config/acheron"
    rm -f "$HOME/.config/ouwou/AcheronHeadlessTokens.ini"
    rm -rf "$HOME/.local/share/ouwou/Acheron"
    rm -rf "$HOME"/acheron-headless-complete-v*
    rm -f "$HOME"/acheron-headless-complete-v*.zip
    systemctl --user daemon-reload 2>/dev/null || true
    systemctl --user reset-failed 2>/dev/null || true
fi

printf 'headacheron installation removed.\n'
if (( REMOVE_DATA == 0 )); then
    printf 'Settings/data were kept. Use --purge to remove them too.\n'
fi
if (( REMOVE_LEGACY == 0 )); then
    printf 'Legacy acherond installs were left alone. Use --legacy to remove them too.\n'
fi
